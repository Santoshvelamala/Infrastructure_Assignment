import os
from fnmatch import fnmatch
import queue as Q
import shutil
def reorder(root):
	#root = '/home/santosh/Documents/InternASS'
	pattern = "*.*"
	files=os.listdir(root)
	for name in files:
		if fnmatch(name, pattern):
		    newpath = os.path.join(root,name.rpartition('.')[2]) 
		    if not os.path.exists(newpath):
	    		os.makedirs(newpath)
		    if not os.path.exists(os.path.join(newpath,name)):
		    	shutil.move(os.path.join(root,name),newpath)
		    else :
			os.remove(name)
	return ["Successfully reordered -:):"]

