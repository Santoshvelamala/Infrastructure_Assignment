
Its a small application which supports five functionalities:

 1. Top n Files:
	Output is top n biggest files in the computer

 2.Organize files:
	Input: Folder(to be organized) path
	Output: All the files in the given folder will be moved into their respective folders based on their extensions

 3.Summarization:
	Takes text file as input and extract summary of it.

 4.Deduplication Of Files in a Folder:
	Input:Path to a folder
	Output:Identifies and remove all the duplicate files from the given folder

 5. Search a file or folder:
	Output is the files and folders matching with the input prefix
--------------------------------------------------------------------------------------------------------------------------

How to run???

>>Python gui.py

Note:
	Since this application is not very well tested, donot run these tasks on your system folders. I have included a
folder(name: TestFolder) in zip file for application testing, So do use them. 
