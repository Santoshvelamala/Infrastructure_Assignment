#!/usr/bin/env python
import Tkinter

from Tkinter import *
import search,TopN,reorder
import summariz,dup_fileremove


def default():
    tex.delete('1.0', END)
    default="This app consists of five sections:\n\n 1. Top n Files:\n	Input: Number of Files (eg:10)\n	Output is top n biggest files in the computer\n\n  2.Organize files:\n	Input: Folder(to be organized) path (eg: ./TestFolder/Organize)\n	Output: All the files in the given folder will be moved into their respective folders based on their extensions\n\n 3.Summarization:\n	Takes text file as input and extract summary of it.(eg: ./TestFolder/apple.txt)\n\n 4.Deduplication Of Files in a Folder:\n	Input:Path to a folder.(eg:./TestFolder/Duplicate)\n	Output:Identifies and remove all the duplicate files from the given folder\n\n 5. Search a file or folder:\n	Input: Prefix of a File or Folder(eg: apple (apple.txt)\n	Output is the files and folders matching with the input prefix\n\n"
    tex.insert(Tkinter.END, default)
    tex.see(Tkinter.END)

top = Tkinter.Tk()
Label(top, text="HEY Hii!!",fg="green",bd=2,font=("Courier", 44,"bold")).pack(side=Tkinter.TOP)

b = Button(master=top, text="Reset",font=("bold"), width=100, command=default,bg="black",fg="white")
b.pack()
tex = Tkinter.Text(master=top,padx=0,pady=0,bd =5,width=90,height=30,bg="grey",fg="white",font=("bold"))
tex.pack(side=Tkinter.LEFT)
bop = Tkinter.Frame()
bop.pack(side=Tkinter.LEFT)


def cbc(id, tex):
    return lambda : callback(id, tex)
def callback():
    tex.delete('1.0', END)
    tex.insert(Tkinter.END, "Searching!! Wait a second"+"\n")
    tex.see(Tkinter.END)
    matches=search.search(e.get())
    if matches:
	    for match in matches:
	    	tex.insert(Tkinter.END, ">>"+match+"\n")
	    tex.see(Tkinter.END)
    else:
    	    tex.insert(Tkinter.END, ">>Sorry, No Matches Found!!!!\n")
	    tex.see(Tkinter.END)	

def callback1():
    tex.delete('1.0', END)
    tex.insert(Tkinter.END, "Searching!! Wait a second"+"\n")
    tex.see(Tkinter.END)
    matches=TopN.TopN(e3.get())
    for match in matches:
	tex.insert(Tkinter.END, ">>"+str(match[1]/1024)+"mb"+">>"+str(match[2])+"\n")
    tex.see(Tkinter.END)

def callback2():
    tex.delete('1.0', END)
    tex.insert(Tkinter.END, "Searching!! Wait a second"+"\n")
    tex.see(Tkinter.END)
    matches=reorder.reorder(e1.get())
    for match in matches:
    	tex.insert(Tkinter.END, ">>"+match+"\n")
    tex.see(Tkinter.END)

def callback3():
    tex.delete('1.0', END)
    tex.insert(Tkinter.END, "Searching!! Wait a second"+"\n")
    tex.see(Tkinter.END)
    file_name=e2.get()
    f=open(file_name)
    text=f.read()
    matches=summariz.summariz(str(text))
    tex.insert(Tkinter.END,matches)
    tex.see(Tkinter.END)

def callback4():
    tex.delete('1.0', END)
    tex.insert(Tkinter.END, "Searching!! Wait a second"+"\n")
    tex.see(Tkinter.END)
    file_name=e4.get()
    dup_fileremove.dup_fileremove(file_name)
    tex.insert(Tkinter.END,file_name+"\n"+"Successfully Deduplicated")
    tex.see(Tkinter.END)


    


default()


Label(top, text="1. Top n files:",font=("bold",10),fg="black").pack()

e3 = Entry(master=top,text="Get",font=("bold"), width=20,bd=2)
e3.pack()
e3.focus_set()
b = Button(master=top, text="Search",font=("bold"), width=10, bd =3,command=callback1,bg="black",fg="white")
b.pack()

'''
Label(top,text="------------------------------",font=("bold","15"),fg="green").pack()

Label(top, text="2. Search a file or folder:",font=("bold",10),fg="black").pack()
Label(top, text="Enter File\Folder name:",font=("bold",10),fg="black").pack()
e = Entry(master=top,text="Search",font=("bold"), width=20,bd=2)
e.pack()
e.focus_set()
b = Button(master=top, text="Search",font=("bold"), width=10, command=callback,bg="black",fg="white")
b.pack()
'''
Label(top,text="------------------------------",font=("bold","15"),fg="green").pack()

Label(top, text="2. Organize Files in Folder:",font=("bold",10),fg="black").pack()
Label(top, text="Enter the path of Folder",font=("bold",10),fg="black").pack()
e1 = Entry(master=top,text="Search",font=("bold"), width=20,bd=2)
e1.pack()
e1.focus_set()
b = Button(master=top, text="Search",font=("bold") ,width=10, command=callback2,bd =3,bg="black",fg="white")
b.pack()
Label(top,text="------------------------------",font=("bold","15"),fg="green").pack()
Label(top, text="3. Text File Summarization:",font=("bold",10),fg="black").pack()
Label(top, text="Enter the path of Textfile",font=("bold",10),fg="black").pack()
e2 = Entry(master=top,text="Search",font=("bold"), width=20,bd=2)
e2.pack()
e2.focus_set()
b = Button(master=top, text="Summarize",font=("bold"), width=10, command=callback3,bd =3,bg="black",fg="white")
b.pack()
Label(top,text="------------------------------",font=("bold","15"),fg="green").pack()

Label(top, text="4. Deduplication Of Files in a Folder:",font=("bold",10),fg="black").pack()
Label(top, text="Enter the folder path:",font=("bold",10),fg="black").pack()
e4 = Entry(master=top,text="Get",font=("bold"), width=20,bd=2)
e4.pack()
e4.focus_set()
b = Button(master=top, text="Search",font=("bold"), width=10,bd =3, command=callback4,bg="black",fg="white")
b.pack()

Label(top,text="------------------------------",font=("bold","15"),fg="green").pack()

Label(top, text="5. Search a file or folder:",font=("bold",10),fg="black").pack()
e = Entry(master=top,text="Search",font=("bold"), width=20,bd=2)
e.pack()
e.focus_set()
b = Button(master=top, text="Search",font=("bold"), width=10,bd =3, command=callback,bg="black",fg="white")
b.pack()
top.mainloop()
