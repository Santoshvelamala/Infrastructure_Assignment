import os
from fnmatch import fnmatch
import queue as Q
import easygui


root = '/home'
pattern = "*.*"
def TopN(n):
	easygui.msgbox("Hold On!!\nThis might take Few seconds", title="Wait for a while")
	Priority_Queue=Q.PriorityQueue()
	for path, subdirs, files in os.walk(root):
	    for name in files:
		if fnmatch(name, pattern):
		    statinfo = os.stat(os.path.join(path, name))
		    Priority_Queue.put((-statinfo.st_size,statinfo.st_size,os.path.join(path,name)))
		    print (statinfo.st_size,os.path.join(path,name))
	topten=[]
	for i in range(int(n)):
		if not Priority_Queue.empty() :
			topten.append(Priority_Queue.get())
	return topten
