import os
from fnmatch import fnmatch
import queue as Q
import easygui
root = '/home'
pattern = "*.*"
def search(file_name):
	easygui.msgbox("Hold On!!\nThis might take Few seconds", title="Wait for a while")
	matches=[]
	for path, subdirs, files in os.walk(root):
    		for name in files:
        		if fnmatch(name, file_name+"*"):
				matches.append(os.path.join(path,name))
				print os.path.join(path,name)
	return matches
