#include<stdio.h>
#include<stdlib.h>

struct node *insert();
typedef
struct node{
	int data;
	struct node * next;
}node;

struct node  *insert(node *head){
	int a;
   	node *temp,*p;
	p=head;
	temp=(node*)malloc(sizeof(node));
	
	   if(head==NULL)
		{head=temp;
     	         scanf("%d",&a);
                 temp->data=a;
                           }
               else
               {
		
                while(p->next!=NULL)
                {p=p->next;}
	
	 	scanf("%d",&a);
		temp->data=a;
		temp->next=NULL;
		p->next=temp;
	
  }

return head;
        
}

void display(node *head){
	node *p;
	p= head;
	while(p!=NULL)
	{
		printf("%d ",p->data);
		p=p->next;
	}

}

void delete(node *head){
	node *p,*q,*prevp,*prevq;
       // int i,j;
	//int count=1;
	p=head;
        q=head;
	//prevp->next=p;
        //q->next=qnext;

	while (p!=NULL)
	{		
		while (q!=NULL)
		{		

		//   printf("%d %d\n",p->data,q->data);
		   if (p->data+q->data==0 && (p==head || q==head))
		   {
			//printf("\n%d %d\n",p->data,q->data);			
			head=head->next;
			p=p->next;			
			if (q!=head)
				prevq->next=q->next;
			else
				head=head->next;
		   }
		   else if (p->data+q->data==0)
		   {
			if (p->next!=NULL && q->next!=NULL)
			{	prevp->next=p->next;
				prevq->next=q->next;
			}

		   }
		   prevq=q;		
		   q=q->next;		
		}
	   q=head;
	   prevp=p;
	   p=p->next;
	}  

display(head);
   
}

int main(){
	
	node* head=NULL;
	int n,i;
	printf("enter size of list.");	
	scanf("%d",&n);
        printf("enter values of the list.");
        for(i=0;i<n;i++)
	{
		head=insert(head);
	}	
	display(head);
        printf("\n");
	delete(head);
    return 0;
  
}



