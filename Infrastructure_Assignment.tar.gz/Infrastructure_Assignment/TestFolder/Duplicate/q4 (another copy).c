#include<stdio.h>
#include<stdlib.h>

typedef
struct node{
   int data;
   struct node* next;
}node;

node* head=NULL;
node *two,*three,*four,*five,*six,*seven;

int main(){

head=(node*)malloc(sizeof(node));
two=(node*)malloc(sizeof(node));
three=(node*)malloc(sizeof(node));
four=(node*)malloc(sizeof(node));
five=(node*)malloc(sizeof(node));
six=(node*)malloc(sizeof(node));
seven=(node*)malloc(sizeof(node));

    
    int i,j;
    node *p,*q;
	    
    	

	head->data=1;
    head->next=two;
   
    two->data=2;
	two->next=three;

    three->data=4;
	three->next=four;
	
	four->data=5;
	four->next=five;

	five->data=6;
	five->next=six;

    six->data=8;
    six->next=seven;

	seven->data=9;
	seven->next=NULL;
	
	p=head;
	q=head;
	for(i=0;i<7;i++)
	{
       for(j=0;j<7;j++)
     	{
     	   if(p->data+q->data==7)
			{
  			printf("(%d,%d)",p->data,q->data);
			}
	q=q->next;		
	}
	q=head;	
	printf("\n");
        p=p->next;
//	p=p->next;
	}

 return 0;
}
