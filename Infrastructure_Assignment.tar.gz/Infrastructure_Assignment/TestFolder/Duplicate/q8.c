#include<stdio.h>
#include<stdlib.h>

typedef
struct node{
 int data;
 struct node* next;
}node;

node* head=NULL;
node *two,*three,*four,*five,*six,*seven,*eight,*nine,*ten;

void display(node *head){
	node *p;
	p= head;
	while(p!=NULL)
	{
		printf("%d ",p->data);
		p=p->next;
	}

}

int main(){

	head=(node*)malloc(sizeof(node));
	two=(node*)malloc(sizeof(node));
	three=(node*)malloc(sizeof(node));
	four=(node*)malloc(sizeof(node));
	five=(node*)malloc(sizeof(node));
	six=(node*)malloc(sizeof(node));
	seven=(node*)malloc(sizeof(node));
	eight=(node*)malloc(sizeof(node));
	nine=(node*)malloc(sizeof(node));
	ten=(node*)malloc(sizeof(node));
    

      int i,count=3;
       node *p;
        p=head;	

	head->data=1;
        head->next=two;
   
        two->data=1;
	two->next=three;

        three->data=1;
	three->next=four;
	
	four->data=3;
	four->next=five;

	five->data=1;
	five->next=six;

        six->data=2;
        six->next=seven;

	seven->data=1;
	seven->next=eight;

	eight->data=1;
	eight->next=nine;

	nine->data=4;
	nine->next=ten;

	ten->data=1;
	ten->next=NULL;
	display(head);
	for(i=0;i<10;i++)
        {
		if(i==0)
		{
			p=p->next;
		}		
		else
		{
			if(p->data==1)
			{
				count=count+1;
				p->data=count;
			//	p=p->next;
			//	display(head);			
			}
			p=p->next;	
		}	
	}
	printf("\n");
	display(head);

return 0;

}

