import copy
import Queue as Q
def DFS(given):
    goal=[1,2,3,4,5,6,7,8,0]
    parent=[]
    visited = []
    queue= [given]
    neigh=[]
    ape=[]
    path={}
    while queue:
	giv=queue.pop()
	print giv
	strparent=''.join(str(e) for e in giv)
	print "//////////////////"
	blank=giv.index(0)
	neigh.append(blank-3)
	neigh.append(blank+3)
	neigh.append(blank-1)
	neigh.append(blank+1)
	q = Q.PriorityQueue()
#	for i in range (4):
		#ape=copy.deepcopy(giv)
		#if neigh[i]>=0 and neigh[i]<=8:
		#	if (ape[neigh[i]]==1 or ape[neigh[i]]==2 or ape[neigh[i]]==3):
		#		q.put((1,neigh[i]))
		#	elif ape[neigh[i]]==4 or ape[neigh[i]]==5 or ape[neigh[i]]==6:
		#		q.put((2,neigh[i]))
		#	elif ape[neigh[i]]==7 or ape[neigh[i]]==8 :
		#		q.put((3,neigh[i]))	
#	while not q.empty():
	for i in range (4):
		ape=copy.deepcopy(giv)
		if neigh[i]>=0 and neigh[i]<=8:
			print neigh[i]
		#t=q.get()
		#i=t[1]
			ape[blank]=ape[neigh[i]]
			ape[neigh[i]]=0
			if ape not in visited:
				visited.append(ape)
				strchild=''.join(str(e) for e in ape)
				path[strchild]=strparent		
				queue.append(ape)
			if ape==goal:
				print "yes"
				stack= [strchild]
				strstart=''.join(str(e) for e in given)
				while strchild != strstart :
					stack.append(path[strchild])
					strchild=path[strchild]
				print stack				
				return
	neigh=[]
	
    

given= [1,2,3,4,0,5,6,7,8]
DFS(given)

