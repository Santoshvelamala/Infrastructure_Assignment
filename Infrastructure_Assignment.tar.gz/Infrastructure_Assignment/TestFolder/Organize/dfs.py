import copy
import Queue as Q
import datetime
import math
from math import sqrt
td=[]
path={}
def dfs(given):
    d = datetime.datetime.now()
    kmin1=getattr(d, 'minute')
    ksec1=getattr(d, 'second')
    kmsec1=getattr(d,'microsecond')
    goal=[1,2,3,4,5,6,7,8,0]
    parent=[]
    visited = []
    queue= [given]
    neigh=[]
    ape=[]
    while queue:
	giv=queue.pop()
	#print giv
	strparent=''.join(str(e) for e in giv)
	#print "//////////////////"
	blank=giv.index(0)
	neigh.append(blank-3)
	neigh.append(blank+3)
	neigh.append(blank-1)
	neigh.append(blank+1)
	q = Q.PriorityQueue()
	for i in range (4):
		ape=copy.deepcopy(giv)
		if neigh[i]>=0 and neigh[i]<=8:
			if (ape[neigh[i]]==1 or ape[neigh[i]]==2 or ape[neigh[i]]==3):
				q.put((1,neigh[i]))
			elif ape[neigh[i]]==4 or ape[neigh[i]]==5 or ape[neigh[i]]==6:
				q.put((1,neigh[i]))
			elif ape[neigh[i]]==7 or ape[neigh[i]]==8 :
				q.put((1,neigh[i]))	
	while not q.empty():
		ape=copy.deepcopy(giv)
		t=q.get()
		i=t[1]
		ape[blank]=ape[i]
		ape[i]=0
		if ape not in visited:
			visited.append(ape)
			strchild=''.join(str(e) for e in ape)
			path[strchild]=strparent		
			queue.append(ape)
		if ape==goal:
			#print "yes"
			stack= [strchild]
			strstart=''.join(str(e) for e in given)
			while strchild != strstart :
				stack.append(path[strchild])
				strchild=path[strchild]
			while len(stack)!=0:
				out=stack.pop()
				print out[0]+" "+out[1]+" "+out[2]
				print out[3]+" "+out[4]+" "+out[5]
				print out[6]+" "+out[7]+" "+out[8]
				print " "
			d = datetime.datetime.now()
    			kmin2=getattr(d, 'minute')
    			ksec2=getattr(d, 'second')
			kmsec2=getattr(d, 'microsecond')
			if ksec1==ksec2:
				tdiff=kmsec2-kmsec1
			else:
				tdiff=((ksec2-ksec1-1)*1000000)+(1000000-kmsec1)+kmsec2
			#print ksec2-ksec1
			#print kmsec1
			#print kmsec2-kmsec1
			
			#print tdiff
			td.append(tdiff)				
			return
	neigh=[]
	
    
given= [1,2,3,4,0,5,6,7,8]
for t in range(5):
	print "Experiment %d " %(t+1) 
	path={}
	dfs(given)
#print td
x1=sum(td)/5
print "Average time for 5 Experiments : %d microsec" %(x1)
sigma=0.0
for i in range(5):
	sigma=sigma+((td[i]-x1)*(td[i]-x1))
su=sigma/5
sd=sqrt(su)
print "Standard Deviation : %d" %(sd)
print "No. of states traversed : %d" %(len(path))

