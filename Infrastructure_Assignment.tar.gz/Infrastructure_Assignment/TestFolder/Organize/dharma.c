/*
Read an Integer Matrix;
find out the matrix is symmetric or not;

input:
	n=3  
	A={{1, 2, 3},
	   {2, 4, 5},
	   {3, 5, 6}}

Output: Symmetric

*/


#include<stdio.h>
int main()
{
	int A[100][100],n;
	scanf("%d",&n);
	for (int i=0;i<n;i++)
	{
		for (int j=0;j<n;j++)
		{

			scanf("%d",&A[i][j]);
		}
	}

	for (int i=0;i<n;i++)
	{
		for (int j=0;j<n;j++)
		{
			if (A[i][j]!=A[j][i])
			{
				printf("Not Symmetric\n");
				return 0;
			}
		}
	}
	printf("Symmetric\n");

return 0;
}
