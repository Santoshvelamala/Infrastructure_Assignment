import java.io.*;
import java.util.*;
import java.lang.*;
class philosoper
{
	boolean thinking;
	boolean hungry;
	boolean eating;	
	philosoper()
	{
		thinking=0;
		eating=0;
		hungry=1;
	}

}

class dp
{
	public static void main (String args[])
	{	boolean spoon[]=new boolean[5];
		for (int i=0;i<5;i++)
			spoon[i]=1;
		int semaphore=0;
		philosoper [] p= new philosoper[5];
		while (1)
		{
		//	for (i=0;i<5;i++)
		//	{
			if (p[semaphore].hungry==1 && spoon[semaphore]==1 && spoon[semaphore+1]==1)
			{
				p[semaphore].eating=1;
				spoon[semaphore]=0;
				spoon[semaphore+1]=0;
				p[semaphore].hungrytime--;
			}
			
			semaphore=(semaphore+1)%5;
		}		
		
	}
}
