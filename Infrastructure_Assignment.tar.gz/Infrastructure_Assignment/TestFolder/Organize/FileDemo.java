import java.io.File;
import java.io.IOException;
import java.util.Scanner;

/**
* Simple Java program to create File and Directory in Java, without using
* any third-party library.

* @author http://java67.blogspot.com
*
*/
public class FileDemo {

    public static void main(String args[]) {
	Dir();
//	Fil();
/*        Scanner reader = new Scanner(System.in);
        boolean success = false;

        System.out.println("Enter path of directory to create");
        String dir = reader.nextLine();

        // Creating new directory in Java, if it doesn't exists
        File directory = new File(dir);
        if (directory.exists()) {
            System.out.println("Directory already exists ...");

        } else {
            System.out.println("Directory not exists, creating now");

            success = directory.mkdir();
            if (success) {
                System.out.printf("Successfully created new directory : %s%n", dir);
            } else {
                System.out.printf("Failed to create new directory: %s%n", dir);
            }
        }*/

      // Creating new file in Java, only if not exists
  /*      System.out.println("Enter file name to be created ");
        String filename = reader.nextLine();

        File f = new File(filename);
        if (f.exists()) {
            System.out.println("File already exists");

        } else {
            System.out.println("No such file exists, creating now");
            success = f.createNewFile();
            if (success) {
                System.out.printf("Successfully created new file: %s%n", f);
            } else {
                System.out.printf("Failed to create new file: %s%n", f);
            }
        }
*/
        // close Scanner to prevent resource leak
      //  reader.close();

    }
	public static void Dir(){
//Scanner reader = new Scanner(System.in);
        boolean success = false;

        System.out.println("Enter path of directory to create");
        String dir = "./Downloads/aj";

        // Creating new directory in Java, if it doesn't exists
       try{ File directory = new File(dir);
        if (directory.exists()) {
            System.out.println("Directory already exists ...");

        } else {
            System.out.println("Directory not exists, creating now");
		success = directory.createNewFile();
            //success = directory.mkdir();
            if (success) {
                System.out.printf("Successfully created new directory : %s%n", dir);
            } else {
                System.out.printf("Failed to create new directory: %s%n", dir);
            }
        }}
	catch(IOException e){
		e.printStackTrace();
	}
}
	/*public static void Fil(){
System.out.println("Enter file name to be created ");
        String filename = "jk";
	 boolean success = false;

        File f = new File(filename);
        if (f.exists()) {
            System.out.println("File already exists");

        } else {
            System.out.println("No such file exists, creating now");
            success = f.createNewFile();
            if (success) {
                System.out.printf("Successfully created new file: %s%n", f);
            } else {
                System.out.printf("Failed to create new file: %s%n", f);
            }
        }}*/
	
}


//Read more: http://www.java67.com/2014/02/how-to-create-file-and-directory-in-java.html#ixzz4RDP6l5BN

