import smtplib
server = smtplib.SMTP('smtp.gmail.com', 587)

#Next, log in to the server
server.login("santosh.velamala", "9440206496")

#Send the mail
msg = "
Hello!" # The /n separates the message from the headers
server.sendmail("santosh.velamala@gmail.com", "santosh.velamala@gmail.com", msg)
