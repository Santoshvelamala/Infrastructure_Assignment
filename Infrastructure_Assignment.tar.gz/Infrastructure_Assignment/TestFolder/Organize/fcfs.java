import java.io.*;
import java.util.*;
import java.util.Arrays;
class fcfs
{
	public static void main (String args[])	
	throws Exception
	{
		InputStreamReader i=new InputStreamReader(System.in);
                BufferedReader br=new BufferedReader(i);
                System.out.println("No of process:");
		int n;
                n=Integer.parseInt(br.readLine());
		int bt[]=new int [n];
		int avg[]=new int[n];
		int arr[]=new int[n];
		int wt[]=new int[n];
		int t;
		for (int j=0;j<n;j++)
		{
			System.out.println("Enter arrival time of:"+(j+1));
			arr[j]=Integer.parseInt(br.readLine());
		}
/*		Arrays.sort(arr);*/
		for (int j=0;j<n;j++)
		{
			System.out.println("Enter Burst Time of:"+(j+1));
			bt[j]=Integer.parseInt(br.readLine());
		}
		for (int j=0;j<n-1;j++)
		{
			for (int k=j+1;k<n;k++)
			{
				if (arr[j]>arr[k])
				{
					int temp1,temp2;
					temp1=arr[j];
					temp2=bt[j];
					arr[j]=arr[k];
					bt[j]=bt[k];
					arr[k]=temp1;
					bt[k]=temp2;
				}
			}
		}
		wt[0]=0;
		for (int j=1;j<n;j++)
		{
			for (int k=j;k>0;k--)
			{
				wt[j]=wt[j]+bt[k];
			}
		}
		for (int j=0;j<n;j++)
		{
			System.out.println(+(wt[j]));
		}
	}
}
