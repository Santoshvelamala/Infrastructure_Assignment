import java.io.*;
import java.lang.*;
class FCFS
{
	public static void main(String args[])
	throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int i,j,sum=0;
		System.out.println("Enter the no. of processes");
		int n = Integer.parseInt(br.readLine());
		int P[] = new int[n];
		int A[] = new int[n];
		int B[] = new int[n];
		int W[] = new int[n];
		for (i=0;i<n;i++)
		{
			System.out.println("Enter the Arrival time of Process "+(i+1));
			A[i] = Integer.parseInt(br.readLine());
			P[i] = i+1;
		}
		for (i=0;i<n;i++)
		{
			System.out.println("Enter the Burst time of Process "+(i+1));
			B[i] = Integer.parseInt(br.readLine());
		}
		int t,t1,t2;
		for (i=0;i<n;i++)
		{
			for (j=i+1;j<n;j++)
			{
				if (A[i]>A[j])
				{
					t=A[i];
					A[i]=A[j];
					A[j]=t;
					t1=B[i];
					B[i]=B[j];
					B[j]=t1;
					t2=P[i];
					P[i]=P[j];
					P[j]=t2;
				}
			}
		}
		W[0] = 0;
		for (i=1;i<n;i++)
		{
			if (A[i]!=A[i-1])
			{
				W[i] = B[i-1] + W[i-1];
				W[i] = W[i]-A[i];
			}
			if (A[i]==A[i-1])
			{
				W[i] = B[i-1] + W[i-1];
			}
			if (W[i]<0)
				W[i] = 0;
		}
		System.out.println(" "+"PD"+" "+"AT"+" "+"BT"+" "+"WT");
		for (i=0;i<n;i++)
		{
			System.out.println(" "+P[i]+" "+A[i]+" "+B[i]+" "+W[i]);
		}
		for (i=0;i<n;i++)
		{
			sum=sum+W[i];
		}
		double awt=0;
		awt = sum/n ; 
		System.out.println("The avg waiting time is "+awt);
	}
}	